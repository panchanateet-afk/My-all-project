/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package handlers;

/**
 *
 * @author panjanathee
 */
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class SafeFileHandler {

    public static final String EDTHESAFE = "v1.0";

    // Simple container for loaded file data
    public static class SafeData {
        public String version;     // "Version of a program (Nothing to do with it)" 
        public String algorithm;   // "KNOB", "KEYHOLE", or "NUMPAD"
        public String puzzleHint;  // Hint text or "NONE"
        public String payload;     // The encrypted text

        public SafeData(String version, String algorithm, String puzzleHint, String payload) {
            this.version = version;
            this.algorithm = algorithm;
            this.puzzleHint = puzzleHint;
            this.payload = payload;
        }
    }

    /**
     * Export: format to the .etsafe file.
     *
     * @param file file name that want to export
     * @param alg algorithm that encrypted the file
     * @param hint hint for guess a password of the file
     * @param encryptedText the encrypted text to export
     * @throws java.lang.Exception
     */
    public static void exportEnFile(File file, String alg, String hint, String encryptedText) throws Exception {
        String safeHint = (hint == null || hint.trim().isEmpty()) ? "NONE" : hint.trim();

        // Single line format: ALGORITHM|HINT|PAYLOAD   
        String lineToSave = "EDTheSafe " + EDTHESAFE + "|" + alg + "|" + safeHint + "|" + encryptedText;

        try (PrintWriter writer = new PrintWriter(file, "UTF-8")) {
            writer.print(lineToSave);
        }
    }

    /**
     * Import: Reads the single line and splits it back into components.
     * @param file
     * @return 
     * @throws java.lang.Exception
     */
    public static SafeData importEnFile(File file) throws Exception {
        try (Scanner scanner = new Scanner(file, "UTF-8")) {
            if (!scanner.hasNextLine()) {
                throw new Exception("File is empty.");
            }
            String line = "";
            while (scanner.hasNextLine()) {
                line += "\n"+scanner.nextLine();          
            }
            scanner.close();
            // Split by '|' (using \\| because | is a special regex character)
            String[] parts = line.split("\\|", 4);

            if (parts.length < 4) {
                throw new Exception("Invalid .etsafe file format.");
            }

            return new SafeData(parts[0], parts[1], parts[2], parts[3]);
        }
    }
    
    public static void exportTxtFile(File file, String text) throws Exception {
        String lineToSave = text;
        try (PrintWriter writer = new PrintWriter(file, "UTF-8")){
            writer.print(lineToSave);
        }
    }
}
