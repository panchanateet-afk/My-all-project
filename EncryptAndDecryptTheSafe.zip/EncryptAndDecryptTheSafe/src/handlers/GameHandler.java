/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package handlers;

import crypto.AES128Cipher;
import crypto.CiphersBase;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;

/**
 *
 * @author panjanathee
 */
public class GameHandler {
    private final String lvlPassword = "level";
    private final Path relativePath = Path.of("EncryptedFlag", "progress.txt");
    private final CiphersBase AES = new AES128Cipher();

    public int loadLvlProgress() throws IOException, Exception {
        String level = AES.decrypt(Files.readString(relativePath), lvlPassword);
        return Integer.parseInt(level.substring(5));
    }

    public void saveLvlProgress(int level) throws IOException, Exception {
        Files.writeString(relativePath, AES.encrypt(("level" + String.valueOf(level)), lvlPassword), StandardCharsets.UTF_8);
    }

    public String getAnswer(int level, String password) {
        if (password.equalsIgnoreCase("panchanatee")) {
            return challengeLvlAnsArr[level];
        }
        return "Who are you? No permission.";
    }

    public String getLevelChallenge(int level) {
        return challengeLvlDescArr[level];
    }

    public boolean isRightFlag(int level, String flag) {
        return flag.strip().equals(FlagArr[level]);
    }
    
    public int getLvlQuantity(){
        return challengeLvlDescArr.length - 1;
    }
    
    private final String[] FlagArr = {
        "EDSAFE{001YOUR3_P4SS3D001}",
        "EDSAFE{H3R3TH3FL4G002}",
        "EDSAFE{43525950545f4d41535445525f313238}",
        "EDSAFE{MODERN_AES_BLOCK_CIPHER_MASTER}",
        "EDSAFE{C0NGR4TUL4T10N_TH4NKY0U_F0R_PL4Y1NG}",
        "..."
    };
    private final String[] challengeLvlAnsArr = {
        "Caesar: 17",
        "Caesar by order: 14 > 10 > 4",
        "Vignere: CRYPT",
        "AES-128: CRYPT_MASTER_128",
        "AES: GRAND_MASTER_43210 > Vigenere: ERASE > Caesar: 25",
        "CONGRATULATIONS THANKS FOR PLAYING"
    };
    private final String[] challengeLvlDescArr = {
        //level 0
        """
    === Level 0: Your First Safe Vault File ===
        
    ยินดีต้อนรับ GRAND_MASTER_43210! หลังจากนี้เราจะเรียกคุณว่า สายลับ ภารกิจของคุณคือการกู้คืน Flag ลับที่ซ่อนอยู่ภายในไฟล์ .etsafe ที่ถูกเข้ารหัสไว้
    
    ภารกิจ:
    1. ไปที่โฟลเดอร์ "EncryptFlag" ในแอปพลิเคชันของโปรเจกต์นี้
    2. คลิกที่ "Import File" และเลือกไฟล์ที่ชื่อว่า "Flag0.etsafe"
    
    คำใบ้ / ข้อมูลสรุป:
    การเข้ารหัสแบบ Caesar (Caesar cipher) จะทำการเลื่อนตำแหน่งตัวอักษรแต่ละตัวไปตามจำนวนที่กำหนดไว้ตายตัว
    ลองดูคำใบ้ที่โหลดมาจากไฟล์ในแท็บ "File description"
    
    ขั้นตอนการแก้โจทย์:
    - กรอกตัวเลขสำหรับเลื่อนตำแหน่งตัวอักษร (shift number) ลงในช่อง Shift Key
    - คลิกปุ่ม "Decrypt"
    - ข้อความต้นฉบับที่ซ่อนอยู่จะปรากฏออกมาในรูปแบบ Flag ลับ: EDSAFE{...}
    
    ส่ง Flag ที่ถูกต้องด้านล่างนี้เพื่อปลดล็อก level 1!
        """,
        //level 1
        """
        === Level 1: Recursive Caesar Echoes ===
        
        สายลับ เป้าหมายได้ยกระดับระบบป้องกันขึ้นไปอีกขั้นแล้ว! การถอดรหัสเพียงรอบเดียวไม่อาจเผยข้อความที่ซ่อนอยู่ได้อีกต่อไป
        
        ภารกิจ:
        1. นำไฟล์ "Flag2.etsafe" เข้าสู่แท็บ "Decryption" (ถอดรหัส)
        2. ตรวจสอบคำใบ้ภายในไฟล์เพื่อค้นหา shift ที่จำเป็น
        
        ความรู้เรื่องรหัสลับ — การเข้ารหัสแบบวนซ้ำ (Recursive/Multi-pass Encryption):
        การเข้ารหัสแบบวนซ้ำเกิดขึ้นเมื่อผลลัพธ์ (output) จากอัลกอริทึมการเข้ารหัสถูกนำกลับเข้าไปในกระบวนการเข้ารหัสอีกครั้งเพื่อใช้เป็นข้อมูลนำเข้า (input) ใหม่ แม้จะใช้อัลกอริทึมเดิมซ้ำ
        
        ในการย้อนกระบวนการเข้ารหัสแบบวนซ้ำด้วยตนเอง คุณต้องดำเนินการย้อนกลับตามลำดับที่ตรงกันข้ามอย่างแม่นยำ (โดยเริ่มถอดรหัสจากชั้นสุดท้ายก่อน)
        
        ขั้นตอนการปฏิบัติ:
        - นำเข้าไฟล์ Flag2.etsafe เข้าไปในแท็บ Decryption
        - ใช้คำใบ้ที่ระบุไว้ในไฟล์เพื่อถอดรหัสทีละชั้น
        - นำคำที่ถอดรหัสแล้วไปถอดรหัสอันต่อไป
        - ดึงค่า Flag ออกมาในรูปแบบ: EDSAFE{...}
        
        ส่ง Flag ที่ถูกต้องด้านล่างนี้เพื่อปลดล็อก level 2!  
        """,
        //level 2
        """
        === Level 2: Polyalphabetic Patterns ===
        
        สายลับ การเลื่อนตำแหน่งตัวอักษรแบบธรรมดาไม่เพียงพออีกต่อไปแล้ว ตอนนี้เป้าหมายกำลังใช้วิธีการเข้ารหัสแบบ Polyalphabetic (ใช้ชุดตัวอักษรหลายชุดในการเข้ารหัส) เพื่อสลับสับเปลี่ยนข้อความที่สื่อสารกัน!
        
        ข้อมูลภารกิจ:
        1. นำไฟล์ "Flag2.etsafe" เข้าสู่แท็บ "Decryption"
        2. ตรวจสอบคำใบ้ภายในไฟล์เพื่อค้นหารหัสผ่านลับ (passphrase)
        
        ความรู้เรื่องรหัสลับ — VIGENÈRE CIPHER:
        ต่างจากรหัส Caesar ที่เลื่อนตำแหน่งตัวอักษรทุกตัวด้วยค่าคงที่ค่าเดียว รหัส Vigenère จะใช้คำหลัก (keyword) ที่วนซ้ำเพื่อเลื่อนตำแหน่งตัวอักษรแต่ละตัวด้วยค่าที่แตกต่างกัน
        
        ตัวอักษรแต่ละตัวในคำหลักของคุณจะเป็นตัวกำหนดระยะการเลื่อนของตัวอักษรที่ตรงกันในข้อความต้นฉบับ (plaintext):
        อย่างเช่น A = ตัวอักษร A ตำแหน่งที่ 0 = A(0)
               B = ตัวอักษร B ตำแหน่งที่ 1 = B(1)
        การเข้ารหัสแบบ Vignere จะเข้ารหัสแบบ:
              text    = ABC (A(0), B(1), C(2))
              shift   = CDE (C(2), D(3), E(4))
            encrypted = CEG (ex. A(0)+C(2) = C(2))
        หากเรารู้คำบางคำที่ตำแหน่งเฉพาะที่ควรจะเป็นหลังจากการถอดรหัสแล้ว
        เราสามารถหา key word ได้ด้วยตัวเอง!
        
        หากคำหลักของคุณสั้น มันจะวนซ้ำไปตลอดทั้งข้อความ (เช่น KEYKEYKEY...)
        
        เคล็ดลับระดับโปร: เนื่องจากคุณทราบว่า Flag ทุกตัวในระบบนี้ขึ้นต้นด้วย "EDSAFE{" การนำตัวอักษร 7 ตัวแรกนี้มาเปรียบเทียบกับข้อความที่ถูกเข้ารหัส (ciphertext) จะช่วยให้คุณคำนวณหาตัวอักษรเริ่มต้นของคำหลักได้!
        
        ขั้นตอนการปฏิบัติ:
        - โหลดไฟล์ Flag2.etsafe เข้าสู่แท็บ Decryption
        - ใช้รหัสผ่านจากคำใบ้ในไฟล์ (หรือหาคำหลักโดยใช้ส่วนหัว EDSAFE{ เป็นตัวช่วย)
        - ถอดรหัสข้อมูล (payload) เพื่อเผยให้เห็น Flag ในรูปแบบ: EDSAFE{...}
        
        ส่ง Flag ที่ถอดรหัสได้ที่ด้านล่างนี้เพื่อปลดล็อก Level 3!
        """,
        //level 3
        """
        === Level 3: Modern Block Security ===
        
        สายลับ รหัสลับแบบดั้งเดิมนั้นไม่อาจต้านทานพลังการประมวลผลของคอมพิวเตอร์ในยุคปัจจุบันได้ ฝ่ายศัตรูได้ยกระดับการป้องกันไปใช้มาตรฐาน AES (Advanced Encryption Standard) ซึ่งเป็นมาตรฐานการเข้ารหัสระดับเดียวกับที่รัฐบาลและกองทัพทั่วโลกใช้งาน!
        
        ข้อมูลภารกิจ:
        1. นำไฟล์ "Flag3.etsafe" เข้าสู่แท็บ "Decryption" 
        2. ตรวจสอบคำใบ้ที่ซ่อนอยู่ภายในไฟล์ เนื่องจากคุณไม่สามารถเจาะรหัส AES ด้วยวิธีทางคณิตศาสตร์ได้โดยตรง คุณจึงต้องค้นหา "คีย์ลับ" ความยาว 16 ตัวอักษรที่ถูกต้องให้พบ!
        
        ความรู้เรื่องรหัสลับ — AES (Advanced Encryption Standard):
        AES เป็นระบบเข้ารหัสแบบ Symmetric Block Cipher สมัยใหม่ ที่ประมวลผลข้อมูลทีละบล็อกขนาดคงที่ 128 บิต (16 ไบต์) โดยผ่านกระบวนการหลายรอบ ทั้งการแทนที่ไบต์ (byte substitution) การเลื่อนแถว (row shift) และการผสมคอลัมน์ (column mixing) ที่ซับซ้อน
        
        คุณสมบัติสำคัญ:
        - กำหนดความยาวคีย์ไว้ตายตัว: AES-128 ต้องใช้คีย์ขนาด 16 ไบต์ (16 ตัวอักษร) พอดี
        - ผลลัพธ์ของ AES จะเป็นข้อมูล raw binary ไม่ใช่ตัวอักษรทั่วไป ดังนั้นข้อความที่ถูกเข้ารหัส (ciphertext) จึงมักแสดงผลในรูปแบบ Base64 (เช่น `e1O+8xQ...`)
        - เนื่องจากการสุ่มเดาคีย์ (brute-force) ขนาด 128 บิตอาจต้องใช้เวลาหลายพันล้านปี โจทย์จึงมักเน้นไปที่การกู้คืนคีย์ (Key Recovery) เช่น การหาคีย์จากข้อมูลข่าวกรองก่อนหน้า โค้ดที่หลุดออกมา หรือช่องทางอื่นๆ
        
        ขั้นตอนการปฏิบัติ:
        - โหลดไฟล์ Flag3.etsafe เข้าไปในแท็บ Decryption
        - แปลงและป้อนคีย์ความยาว 16 ตัวอักษรที่ได้จากข้อมูลภารกิจด่านที่ 2
        - ทำการถอดรหัสข้อมูล (payload) เพื่อเปิดเผย Flag สุดท้ายในรูปแบบ: EDSAFE{...}
        
        ส่ง Flag ที่กู้คืนได้ในช่องด้านล่างเพื่อจบเกม!
        """,
        //level 4
        """
        === Level 4: The Grand Synthesis (Final Boss) ===
        
        ยินดีต้อนรับสู่แกนกลางระบบ สายลับ ข้อมูลสำคัญของเป้าหมายถูกล็อกไว้ด้วยการเข้ารหัส AES-128 
        แต่กุญแจถอดรหัสนั้นอยู่ในคำใบ้ของไฟล์ และดูเหมือนว่าไฟล์จะเข้ารหัสโดยใช้ทุก Cipher ที่ผ่านมา
        
        ข้อมูลภารกิจ:
        1. นำไฟล์ "Flag4.etsafe" เข้าสู่แท็บ "Decryption"
        2. หา key ที่ซ่อนอยู่เพื่อถอดรหัสไฟล์นี้ให้ได้
        
        นี่เป็นด่านสุดท้ายแล้ว โชคดีสายลับ! 
        
        ส่งค่า Flag สุดท้ายที่ด้านล่างนี้เพื่อจบเกม!
        """,
        """
_____________________________________________________________________________________
        
                    VAULT OVERRIDE COMPLETE - ALL LAYERS DEFEATED
_____________________________________________________________________________________
"""};

}
