package crypto;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author panjanathee
 */
public interface CiphersBase{
    String encrypt(String text, String key) throws Exception;
    String decrypt(String ciphertext, String key) throws Exception;
    
}


