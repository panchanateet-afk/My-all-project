/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crypto;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
/**
 *
 * @author panjanathee
 */
public class AES128Cipher implements CiphersBase{
    private static final String ALGORITHM = "AES/CBC/PKCS5Padding";
    private static final int KEY_LENGTH_BITS = 128;
    private static final int IV_LENGTH_BYTES = 16;
    private static final int PBKDF2_ITERATIONS = 10000;
    
    // Fixed salt for simple key derivation from PIN
    private static final byte[] SALT = "SafeNumpadSalt123!".getBytes(StandardCharsets.UTF_8);

    /**
     * Derives a 128-bit AES key from a PIN code string using PBKDF2.
     */
    private static SecretKey deriveKeyFromPin(String pin) throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(pin.toCharArray(), SALT, PBKDF2_ITERATIONS, KEY_LENGTH_BITS);
        byte[] keyBytes = factory.generateSecret(spec).getEncoded();
        return new SecretKeySpec(keyBytes, "AES");
    }

    /**
     * Encrypts plaintext using a PIN password entered on the numpad.
     * 
     * @param plainText Text note to encrypt
     * @param pin       Numeric code or string password from safe numpad
     * @return Base64-encoded string combining IV and Ciphertext
     * @throws java.lang.Exception
     */
    @Override
    public String encrypt(String plainText, String pin) throws Exception {
        if (plainText == null || pin == null || pin.isEmpty()) {
            throw new IllegalArgumentException("Text and PIN must not be empty.");
        }

        // 1. Derive 128-bit AES key from the user PIN
        SecretKey secretKey = deriveKeyFromPin(pin);

        // 2. Generate a random 16-byte Initialization Vector (IV)
        byte[] ivBytes = new byte[IV_LENGTH_BYTES];
        SecureRandom random = new SecureRandom();
        random.nextBytes(ivBytes);
        IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);

        // 3. Initialize Cipher in ENCRYPT mode
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivSpec);

        // 4. Perform AES Encryption
        byte[] encryptedBytes = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));

        // 5. Combine [IV + Encrypted Payload] into a single byte array
        byte[] combined = new byte[ivBytes.length + encryptedBytes.length];
        System.arraycopy(ivBytes, 0, combined, 0, ivBytes.length);
        System.arraycopy(encryptedBytes, 0, combined, ivBytes.length, encryptedBytes.length);

        // 6. Encode to Base64 for file export
        return Base64.getEncoder().encodeToString(combined);
    }

    /**
     * Decrypts Base64 payload using the PIN password entered on the numpad.
     * 
     * @param cipherTextCombined Base64 string containing [IV + Ciphertext]
     * @param pin                Numeric code or string password from safe numpad
     * @return Original decrypted text
     * @throws java.lang.Exception
     */
    @Override
    public String decrypt(String cipherTextCombined, String pin) throws Exception {
        if (cipherTextCombined == null || pin == null || pin.isEmpty()) {
            throw new IllegalArgumentException("Ciphertext and PIN must not be empty.");
        }

        // 1. Decode Base64 string to raw bytes
        byte[] combined = Base64.getDecoder().decode(cipherTextCombined);
        if (combined.length < IV_LENGTH_BYTES) {
            throw new IllegalArgumentException("Invalid encrypted payload format.");
        }

        // 2. Separate IV (first 16 bytes) and Ciphertext (remaining bytes)
        byte[] ivBytes = new byte[IV_LENGTH_BYTES];
        byte[] encryptedBytes = new byte[combined.length - IV_LENGTH_BYTES];
        System.arraycopy(combined, 0, ivBytes, 0, IV_LENGTH_BYTES);
        System.arraycopy(combined, IV_LENGTH_BYTES, encryptedBytes, 0, encryptedBytes.length);

        // 3. Derive key from PIN and prepare IV spec
        SecretKey secretKey = deriveKeyFromPin(pin);
        IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);

        // 4. Initialize Cipher in DECRYPT mode
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivSpec);

        // 5. Perform AES Decryption
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
        return new String(decryptedBytes, StandardCharsets.UTF_8);
    }
}
