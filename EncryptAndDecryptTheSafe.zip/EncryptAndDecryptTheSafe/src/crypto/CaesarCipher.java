/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crypto;

/**
 *
 * @author panjanathee
 */
public class CaesarCipher implements CiphersBase {

    @Override
    public String encrypt(String text, String shift) {
        if (text == null || shift == null || shift.isEmpty()) {
            return text;
        }
// Normalize shift to stay within 0-25 range
        int k = (Integer.parseInt(shift) % 26 + 26) % 26;
        StringBuilder result = new StringBuilder();

        for (char ch : text.toCharArray()) {
            if (Character.isUpperCase(ch)) {
                char shifted = (char) ('A' + (ch - 'A' + k) % 26);
                result.append(shifted);
            } else if (Character.isLowerCase(ch)) {
                char shifted = (char) ('a' + (ch - 'a' + k) % 26);
                result.append(shifted);
            } else {
                // Keep spaces, numbers, and symbols unchanged
                result.append(ch);
            }
        }

        return result.toString();
    }

    /**
     *
     * @param ciphertext must be encrypted string  
     * @param shift shift value as a key
     * @return return a decrypted string
     */
    @Override
    public String decrypt(String ciphertext, String shift) {
        return encrypt(ciphertext, String.valueOf(26 - (Integer.parseInt(shift) % 26)));
    }
}
