/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crypto;

/**
 *
 * @author panjanathee
 */
public class VigenereCipher implements CiphersBase{

    @Override
    public String encrypt(String text, String key) {
if (text == null || key == null || key.isEmpty()) {
            return text;
        }

        StringBuilder result = new StringBuilder();
        String cleanedKey = key.toUpperCase();
        int keyIndex = 0;
        int keyLength = cleanedKey.length();

        for (char ch : text.toCharArray()) {
            if (Character.isLetter(ch)) {
                // Calculate shift based on current character of the keyword (0 - 25)
                int shift = cleanedKey.charAt(keyIndex % keyLength) - 'A';

                if (Character.isUpperCase(ch)) {
                    char shifted = (char) ('A' + (ch - 'A' + shift) % 26);
                    result.append(shifted);
                } else {
                    char shifted = (char) ('a' + (ch - 'a' + shift) % 26);
                    result.append(shifted);
                }

                // Advance key pointer ONLY when an alphabetic character is encrypted
                keyIndex++;
            } else {
                // Keep spaces, numbers, and symbols unchanged
                result.append(ch);
            }
        }
        return result.toString();
    }

    @Override
    public String decrypt(String ciphertext, String key) {
        if (ciphertext == null || key == null || key.isEmpty()) {
            return ciphertext;
        }

        StringBuilder result = new StringBuilder();
        String cleanedKey = key.toUpperCase();
        int keyIndex = 0;
        int keyLength = cleanedKey.length();

        for (char ch : ciphertext.toCharArray()) {
            if (Character.isLetter(ch)) {
                int shift = cleanedKey.charAt(keyIndex % keyLength) - 'A';

                if (Character.isUpperCase(ch)) {
                    char shifted = (char) ('A' + (ch - 'A' - shift + 26) % 26);
                    result.append(shifted);
                } else {
                    char shifted = (char) ('a' + (ch - 'a' - shift + 26) % 26);
                    result.append(shifted);
                }

                keyIndex++;
            } else {
                result.append(ch);
            }
        }

        return result.toString();
    }
    
}
